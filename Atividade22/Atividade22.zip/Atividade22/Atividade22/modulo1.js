let texto = "observe que essa mensagem vem do modulo";
module.exports = texto;

