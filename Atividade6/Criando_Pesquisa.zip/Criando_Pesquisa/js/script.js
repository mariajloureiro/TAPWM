let respostas = [];

const estrelas = document.querySelectorAll('.estrela');
const opiniaoInput = document.getElementById('opiniao');

estrelas.forEach((estrela, index) => {
  estrela.addEventListener('click', () => {
    opiniaoInput.value = index + 1;
    estrelas.forEach(e => e.classList.remove('selecionada'));
    for (let i = 0; i <= index; i++) {
      estrelas[i].classList.add('selecionada');
    }
  });
});

document.getElementById('pesquisaForm').addEventListener('submit', function (e) {
  e.preventDefault();
  const idade = parseInt(document.getElementById('idade').value);
  const sexo = document.getElementById('sexo').value;
  const opiniao = parseInt(opiniaoInput.value);

  respostas.push({ idade, sexo, opiniao });

  alert("Resposta registrada!");
  this.reset();
  estrelas.forEach(e => e.classList.remove('selecionada'));
});

document.getElementById('verResultados').addEventListener('click', function () {
  const total = respostas.length;
  if (total === 0) return alert("Nenhuma resposta registrada ainda.");

  let somaIdade = 0;
  let maisVelho = 0;
  let maisNovo = Infinity;
  let pessimo = 0;
  let otimoOuBom = 0;
  let masc = 0, fem = 0, outros = 0;

  respostas.forEach(r => {
    somaIdade += r.idade;
    if (r.idade > maisVelho) maisVelho = r.idade;
    if (r.idade < maisNovo) maisNovo = r.idade;
    if (r.opiniao === 1) pessimo++;
    if (r.opiniao === 3 || r.opiniao === 4) otimoOuBom++;
    if (r.sexo === "masculino") masc++;
    else if (r.sexo === "feminino") fem++;
    else outros++;
  });

  const media = (somaIdade / total).toFixed(1);
  const porcentagem = ((otimoOuBom / total) * 100).toFixed(1);

  const html = `
    <p><strong>Média das idades:</strong> ${media} anos</p>
    <p><strong>Pessoa mais velha:</strong> ${maisVelho} anos</p>
    <p><strong>Pessoa mais nova:</strong> ${maisNovo} anos</p>
    <p><strong>Quantidade que respondeu péssimo:</strong> ${pessimo}</p>
    <p><strong>Porcentagem que respondeu ótimo ou bom:</strong> ${porcentagem}%</p>
    <p><strong>Homens:</strong> ${masc}, <strong>Mulheres:</strong> ${fem}, <strong>Outros:</strong> ${outros}</p>
  `;

  document.getElementById('resultados').innerHTML = html;
  document.getElementById('modalResultados').style.display = "flex";
});

function fecharModal() {
  document.getElementById('modalResultados').style.display = "none";
}
