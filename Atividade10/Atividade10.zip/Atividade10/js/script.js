const funcionario1 = {
  matricula: "001",
  nome: "Maria Júlia Loureiro",
  funcao: "Desenvolvedora Front-End"
};


const funcionario2 = new Object();
funcionario2.matricula = "002";
funcionario2.nome = "Ana Luiza Alves";
funcionario2.funcao = "Analista de Dados";

function Funcionario(matricula, nome, funcao) {
  this.matricula = matricula;
  this.nome = nome;
  this.funcao = funcao;
}

const funcionario3 = new Funcionario("003", "Daniela da Costa", "Suporte");

const output = document.getElementById("output");

function exibirFuncionario(funcionario, forma) {
  return `<strong>Forma ${forma}</strong><br>
    Matrícula: ${funcionario.matricula}<br>
    Nome: ${funcionario.nome}<br>
    Função: ${funcionario.funcao}<br><br>`;
}

output.innerHTML =
  exibirFuncionario(funcionario1, "1 - Objeto Literal") +
  exibirFuncionario(funcionario2, "2 - new Object()") +
  exibirFuncionario(funcionario3, "3 - Função Construtora");
