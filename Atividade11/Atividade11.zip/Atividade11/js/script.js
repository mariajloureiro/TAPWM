function mostrarTela(tela) {
  document.getElementById("tela-inicial").classList.add("escondido");
  document.getElementById("tela-retangulo").classList.add("escondido");
  document.getElementById("tela-conta").classList.add("escondido");

  if (tela === "retangulo") {
    document.getElementById("tela-retangulo").classList.remove("escondido");
  } else if (tela === "conta") {
    document.getElementById("tela-conta").classList.remove("escondido");
  }
}

function voltarMenu() {
  document.getElementById("tela-retangulo").classList.add("escondido");
  document.getElementById("tela-conta").classList.add("escondido");
  document.getElementById("tela-inicial").classList.remove("escondido");
}

function Retangulo(x, y) {
  this.base = x;
  this.altura = y;
  this.calcularArea = function () {
    return this.base * this.altura;
  };
}

function calcularArea() {
  const base = parseFloat(document.getElementById("base").value);
  const altura = parseFloat(document.getElementById("altura").value);

  if (isNaN(base) || isNaN(altura)) {
    document.getElementById("resultadoRetangulo").textContent = "Preencha todos os campos corretamente.";
    return;
  }

  const ret = new Retangulo(base, altura);
  document.getElementById("resultadoRetangulo").textContent = `Área: ${ret.calcularArea()}`;
}

class Conta {
  set nome(value) { this._nome = value; }
  get nome() { return this._nome; }

  set banco(value) { this._banco = value; }
  get banco() { return this._banco; }

  set numero(value) { this._numero = value; }
  get numero() { return this._numero; }

  set saldo(value) { this._saldo = value; }
  get saldo() { return this._saldo; }
}

class Corrente extends Conta {
  set especial(value) { this._especial = value; }
  get especial() { return this._especial; }
}

class Poupanca extends Conta {
  set juros(value) { this._juros = value; }
  get juros() { return this._juros; }

  set vencimento(value) { this._vencimento = value; }
  get vencimento() { return this._vencimento; }
}

function criarConta() {
  const tipo = document.getElementById("tipoConta").value;
  const nome = document.getElementById("nome").value;
  const banco = document.getElementById("banco").value;
  const numero = document.getElementById("numero").value;
  const saldo = parseFloat(document.getElementById("saldo").value);

  if (!tipo || !nome || !banco || !numero || isNaN(saldo)) {
    document.getElementById("resultadoConta").textContent = "Preencha os campos obrigatórios corretamente.";
    return;
  }

  let resultado = "";

  if (tipo === "corrente") {
    const conta = new Corrente();
    conta.nome = nome;
    conta.banco = banco;
    conta.numero = numero;
    conta.saldo = saldo;
    conta.especial = parseFloat(document.getElementById("especial").value) || 0;

    resultado = `Conta Corrente de ${conta.nome} no banco ${conta.banco}. Nº ${conta.numero}. Saldo: R$${conta.saldo}. Especial: R$${conta.especial}`;
  } else if (tipo === "poupanca") {
    const conta = new Poupanca();
    conta.nome = nome;
    conta.banco = banco;
    conta.numero = numero;
    conta.saldo = saldo;
    conta.juros = parseFloat(document.getElementById("juros").value) || 0;
    conta.vencimento = document.getElementById("vencimento").value;

    resultado = `Conta Poupança de ${conta.nome} no banco ${conta.banco}. Nº ${conta.numero}. Saldo: R$${conta.saldo}. Juros: ${conta.juros}%. Vencimento: ${conta.vencimento}`;
  }

  document.getElementById("resultadoConta").textContent = resultado;
}
