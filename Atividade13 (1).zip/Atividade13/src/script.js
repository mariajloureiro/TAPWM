const inputTexto = document.getElementById('texto');
const radios = Array.from(document.querySelectorAll('input[name="formatacao"]'));
const resultadoEl = document.getElementById('resultado');
const btnLimpar = document.getElementById('btnLimpar');


function atualizarResultado() {
  const texto = inputTexto.value || '';
  const radioSelecionado = radios.find(r => r.checked);
  if (!radioSelecionado) {
    resultadoEl.textContent = texto;
    return;
  }

  switch (radioSelecionado.value) {
    case 'maiuscula':
      resultadoEl.textContent = texto.toUpperCase();
      break;
    case 'minuscula':
      resultadoEl.textContent = texto.toLowerCase();
      break;
    case 'original':
    default:
      resultadoEl.textContent = texto;
      break;
  }
}

inputTexto.addEventListener('input', atualizarResultado);
radios.forEach(r => r.addEventListener('change', atualizarResultado));
btnLimpar.addEventListener('click', () => {
  inputTexto.value = '';

  const original = radios.find(r => r.value === 'original');
  if (original) original.checked = true;
  atualizarResultado();
});

document.addEventListener('DOMContentLoaded', atualizarResultado);
