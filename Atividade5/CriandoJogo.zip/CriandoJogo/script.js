let nomeUsuario = "";

function abrirModal() {
  document.getElementById("modalNome").style.display = "flex";
}

function confirmarNome() {
  const nome = document.getElementById("nome").value.trim();

  if (nome === "") {
    alert("Por favor, digite seu nome!");
    return;
  }

  nomeUsuario = nome;

  document.getElementById("modalNome").style.display = "none";
  document.getElementById("telaInicial").style.display = "none";
  document.getElementById("telaJogo").style.display = "block";
  document.getElementById("boasVindas").innerText = `Boa sorte, ${nomeUsuario}! Escolha sua jogada:`;
}

function jogar(escolhaUsuario) {
  const opcoes = ["pedra", "papel", "tesoura"];
  const numeroAleatorio = Math.floor(Math.random() * 3);
  const escolhaComputador = opcoes[numeroAleatorio];

  let resultado = "";

  if (escolhaUsuario === escolhaComputador) {
    resultado = `Empate! 🤝 Ambos escolheram ${escolhaUsuario}.`;
  } else if (
    (escolhaUsuario === "pedra" && escolhaComputador === "tesoura") ||
    (escolhaUsuario === "tesoura" && escolhaComputador === "papel") ||
    (escolhaUsuario === "papel" && escolhaComputador === "pedra")
  ) {
    resultado = `${nomeUsuario}, você ganhou! 🎉 (${escolhaUsuario} vence ${escolhaComputador})`;
    exibirFogos();  // Chama a função para exibir fogos de artifício
  } else {
    resultado = `${nomeUsuario}, você perdeu! 😢 (${escolhaComputador} vence ${escolhaUsuario})`;
  }

  document.getElementById("resultado").innerText = resultado;
}

function exibirFogos() {
  const canvas = document.getElementById('fireworksCanvas');
  const ctx = canvas.getContext('2d');
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
  canvas.style.display = 'block';

  const particles = [];

  function criarParticulas(x, y) {
    for (let i = 0; i < 100; i++) {
      particles.push({
        x,
        y,
        radius: Math.random() * 3 + 2,
        color: `hsl(${Math.random() * 360}, 100%, 50%)`,
        speedX: Math.random() * 6 - 3,
        speedY: Math.random() * 6 - 3,
        alpha: 1
      });
    }
  }

  function animar() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    particles.forEach((p, index) => {
      p.x += p.speedX;
      p.y += p.speedY;
      p.alpha -= 0.01;

      if (p.alpha <= 0) {
        particles.splice(index, 1);
      } else {
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fillStyle = p.color;
        ctx.globalAlpha = p.alpha;
        ctx.fill();
        ctx.closePath();
      }
    });

    ctx.globalAlpha = 1;

    if (particles.length > 0) {
      requestAnimationFrame(animar);
    } else {
      canvas.style.display = 'none';
    }
  }

  criarParticulas(canvas.width / 2, canvas.height / 2);
  animar();
}
