function calcularIMC() {
  let altura = parseFloat(document.getElementById('altura').value);
  const peso = parseFloat(document.getElementById('peso').value);
  const resultado = document.getElementById('resultado');

  if (isNaN(altura) || isNaN(peso) || altura <= 0 || peso <= 0) {
    resultado.innerHTML = "⚠️ Por favor, insira valores válidos!";
    return;
  }

  if (altura > 3) {
    altura = altura / 100;
  }

  const imc = peso / (altura * altura);
  let classificacao = "";
  let grau = "";

  if (imc < 18.5) {
    classificacao = "MAGREZA";
    grau = "0";
  } else if (imc < 25.0) {
    classificacao = "NORMAL";
    grau = "0";
  } else if (imc < 30.0) {
    classificacao = "SOBREPESO";
    grau = "I";
  } else if (imc < 40.0) {
    classificacao = "OBESIDADE";
    grau = "II";
  } else {
    classificacao = "OBESIDADE GRAVE";
    grau = "III";
  }

  resultado.innerHTML = `
    <p><strong>IMC:</strong> ${imc.toFixed(2)}</p>
    <p><strong>Classificação:</strong> ${classificacao}</p>
    <p><strong>Obesidade (CRAU):</strong> ${grau}</p>
  `;
}
