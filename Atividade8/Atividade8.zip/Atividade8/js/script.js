function mostrarEtapa(numero) {
    const etapas = document.querySelectorAll('.etapa');
    etapas.forEach(etapa => etapa.style.display = 'none');
  
    const etapaSelecionada = document.getElementById(`etapa${numero}`);
    etapaSelecionada.style.display = 'block';
  
    const inputs = etapaSelecionada.querySelectorAll('input');
    inputs.forEach(input => input.value = '');
  
    const respostas = etapaSelecionada.querySelectorAll('p');
    respostas.forEach(res => res.textContent = '');
  }
  
  function maiorNumero() {
    const n1 = Number(document.getElementById("num1").value);
    const n2 = Number(document.getElementById("num2").value);
    const n3 = Number(document.getElementById("num3").value);
    const maior = Math.max(n1, n2, n3);
    document.getElementById("res1").textContent = `Maior número: ${maior}`;
  }
  
  function ordemCrescente() {
    const nums = [
      Number(document.getElementById("ord1").value),
      Number(document.getElementById("ord2").value),
      Number(document.getElementById("ord3").value)
    ];
    nums.sort((a, b) => a - b);
    document.getElementById("res2").textContent = `Ordem crescente: ${nums.join(", ")}`;
  }
  
  function verificarPalindromo() {
    let texto = document.getElementById("texto").value.toLowerCase().replace(/\s/g, "");
    let reverso = texto.split("").reverse().join("");
    let resposta = texto === reverso ? "É um palíndromo!" : "Não é um palíndromo.";
    document.getElementById("res3").textContent = resposta;
  }
  
  function verificarSubconjunto() {
    let p1 = document.getElementById("palavra1").value.toLowerCase();
    let p2 = document.getElementById("palavra2").value.toLowerCase();
    let res = document.getElementById("res4");
  
    if (!p1 || !p2) {
      res.textContent = "Erro: palavra vazia.";
    } else if (p1.includes(p2)) {
      res.textContent = "É um subconjunto.";
    } else {
      res.textContent = "Não é um subconjunto.";
    }
  }
  