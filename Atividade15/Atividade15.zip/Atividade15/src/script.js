function abrirCurso() {
  const select = document.getElementById("cursoSelect");
  const curso = select.value;

  if (!curso) return;

  const conteudos = {
    ads: `<h2>Análise e Desenvolvimento de Sistemas</h2>
          <p>O tecnólogo em Análise e Desenvolvimento de Sistemas analisa, projeta, documenta, especifica, testa, implanta e mantém sistemas computacionais de informação. Esse profissional trabalha, também, com ferramentas computacionais, equipamentos de informática e metodologia de projetos na produção de sistemas. Raciocínio lógico, emprego de linguagens de programação e de metodologias de construção de projetos, preocupação com a qualidade, usabilidade, robustez, integridade e segurança de programas computacionais são fundamentais à atuação desse profissional.</p>`,

    eletronica: `<h2>Eletrônica Automotiva</h2>
          <p>O tecnólogo em Eletrônica Automotiva participa de equipes de desenvolvimento de novos produtos, novas tecnologias e subsistemas na área automotiva; supervisiona, coordena e orienta equipes na área automotiva; realiza a padronização, mensuração e controle de qualidade nas áreas automotivas de veículos especiais, carga e passeio; especifica instrumentos e equipamentos para teste de veículos; oferece assistência, assessoria e consultoria referentes a instrumentos e equipamentos usados em testes de veículos de especiais, carga e passeio.</p>`,

    fabricacao: `<h2>Fabricação Mecânica</h2>
          <p>O egresso do CST em Fabricação Mecânica poderá atuar no projeto e na supervisão de sistemas de operações mecânicas, voltados a processos de fabricação. Domina o funcionamento, as características e a manutenção de máquinas operatrizes, máquinas-ferramenta, ferramentas e dispositivos em geral, podendo administrar todo um processo de produção mecânica. Tem domínio também dos processos de produção com base na automação mecânica. Tem conhecimento dos controles administrativos da produção, podendo atuar na área de organização e no gerenciamento de sistemas de produção. Sabe como utilizar os materiais de construção mecânica e tem domínio sobre projeto de máquinas, ferramentas e dispositivos de produção. Pode dedicar-se ao ensino e à pesquisa tecnológica, bem como realizar vistoria, avaliação e elaboração de laudo técnico em seu campo profissional. Para que o egresso alcance o perfil citado, o CST em Fabricação Mecânica desenvolve em seus componentes temáticas transversais, competências profissionais e socioemocionais.</p>`,

    gestaoEmp: `<h2>Gestão Empresarial – EAD</h2>
          <p>O Tecnólogo em Gestão Empresarial elabora e implementa planos de negócios, utilizando métodos e técnicas de gestão na formação e organização empresarial especificamente nos processos de comercialização, suprimento, armazenamento, movimentação de materiais e no gerenciamento de recursos financeiros e humanos. A habilidade para lidar com pessoas, capacidade de comunicação, trabalho em equipe, liderança, negociação, busca de informações, tomada de decisão em contextos econômicos, políticos, culturais e sociais distintos, são requisitos importantes a esse profissional.</p>`,

    gestaoQualidade: `<h2>Gestão da Qualidade</h2>
          <p>O Tecnólogo em Gestão da Qualidade será um profissional que planeja, implementa e audita sistemas de gestão da qualidade. Realiza mapeamento de processos organizacionais segundo indicadores de qualidade e produtividade. Elabora e analisa documentação e relatórios de qualidade, considerando normas de qualidade estabelecidas. Desenvolve avaliação sistemática dos procedimentos, práticas e rotinas internas e externas de uma organização. Mobiliza pessoas para agir com qualidade em todas as atividades corporativas. Dissemina a cultura da qualidade em todos os setores da empresa. Capacita pessoas em procedimentos e rotinas destinados a minimizar a produção fora de conformidade (utilizando softwares específicos). Elabora ferramentas para minimizar a incidência de falhas, através da análise de dados (Estatística), Lean, Six Sigma, conduz programas de melhorias na empresa. Elabora e gerencia estratégias para obtenção de certificações, garantia e auditoria da Qualidade. Desenvolve programa de avaliação de performance organizacional considerando aspectos quantitativos e qualitativos. Avalia e emite parecer técnico em sua área de formação.</p>`,

    logistica: `<h2>Logística</h2>
          <p>O tecnólogo em Logística é o profissional especializado em armazenagem, distribuição e transporte. Atuando na área logística de uma empresa, planeja e coordena a movimentação física e de informações sobre as operações multimodais de transporte, para proporcionar fluxo otimizado e de qualidade para peças, matérias-primas e produtos. Ele gerencia redes de distribuição e unidades logísticas, estabelecendo processos de compras, identificando fornecedores, negociando e estabelecendo padrões de recebimento, armazenamento, movimentação e embalagem de materiais, podendo ainda ocupar-se do inventário de estoques, sistemas de abastecimento, programação e monitoramento do fluxo de pedidos.</p>`,

    manufatura: `<h2>Manufatura Avançada</h2>
          <p>O aluno aprenderá a transformar ambientes de manufatura convencional em ambientes mais tecnológicos. Estruturado por blocos temáticos direcionados a projetos, o conteúdo do curso é dividido em processos de manufatura, eletrônica e automação e áreas multidisciplinares. O aluno terá uma base de artes para desenho técnico, matemática para cálculos de projetos e gestão de carreira. O inglês para linguagem técnica também é uma disciplina recorrente no curso.</p>`,

    aeronaves: `<h2>Manutenção de Aeronaves</h2>
          <p>A estrutura das aeronaves e de seus sistemas e componentes – aviões de transporte de passageiros, aviões executivos, helicópteros – e as características dos materiais utilizados na fabricação; o funcionamento e a manutenção dos sistemas hidráulicos, de trens de pouso, de ar condicionado e dos propulsores, além dos processos de reparos estruturais e soldagem. O aluno também aprende a utilizar as publicações técnicas e manuais de aviões e dos componentes, estuda desenho técnico, inglês técnico aplicado à aviação, informática e legislação. As disciplinas fundamentais para o aprendizado das matérias profissionalizantes são cálculo, física, álgebra e geometria.</p>`,

    polimeros: `<h2>Polímeros</h2>
          <p>Esse profissional trabalha na fabricação dos Polímeros, compostos químicos utilizados na fabricação de produtos como o plástico, por exemplo. Avalia o desempenho de equipamentos e processos, interpreta fluxogramas de processos, aplica formulação química de polímeros, tintas e vernizes e desenvolve métodos de análises laboratoriais para caracterização dos materiais poliméricos, além de processos de modelagem. O monitoramento da qualidade e dos processos de reciclagem envolvidos; a identificação e acompanhamento das variáveis relevantes, inclusive as referentes ao meio ambiente, são também funções desse profissional.</p>`,

    metalurgia: `<h2>Processos Metalúrgicos</h2>
          <p>O tecnólogo em Processos Metalúrgicos utiliza os fenômenos envolvidos em processos como: tratamentos térmicos, fundição, siderurgia, laminação, forjamento de metais, sinterização e tratamentos de superfície. São atividades inerentes aos egressos deste Curso o planejamento, gestão, controle dos processos e comercialização dos produtos metalúrgicos, através da seleção, dimensionamento de equipamentos e métodos de fabricação. Incluem-se as atividades de laboratórios de ensaios mecânicos e de ensaios metalográficos, com o domínio da interrelação entre microestrutura, propriedades e aplicações dos produtos metálicos. Este profissional possui competências de gestão ambiental, de pessoas e processos industriais. Pode atuar em diversas empresas do ramo metal-mecânico e ainda no ensino superior.</p>`,

    biomedicos: `<h2>Sistemas Biomédicos</h2>
          <p>O tecnólogo em Sistemas Biomédicos é responsável por planejar, gerenciar, implantar e manter equipamentos clínicos e médico-hospitalares. Supervisiona e coordena equipes de manutenção e otimização do uso de equipamentos eletromédicos. Assessora a aquisição, executa a instalação, capacita usuários de equipamentos e sistemas biomédicos, além de participar de equipes de pesquisa aplicada. Responsável também pela implantação e controle das normas de segurança dos equipamentos nos serviços de saúde, pode atuar em hospitais, policlínicas, laboratórios, fabricantes e distribuidoras de equipamentos hospitalares.</p>`,

    projetosMec: `<h2>Projetos Mecânicos</h2>
          <p>O tecnólogo em Projetos Mecânicos está habilitado a realizar projetos, com detalhamento técnico de sistemas mecânicos que envolvam máquinas, motores, instalações mecânicas e termo-mecânicas. Tem conhecimento de todos os materiais usuais em construção mecânica e suas aplicações práticas. Está capacitado a atuar na área de organização industrial mecânica, tanto para processos como para produtos industriais. Domina a técnica do projeto de dispositivos e ferramentas de produção mecânica. Pode dedicar-se ao ensino, à pesquisa tecnológica, bem como realizar vistoria, avaliação e laudo técnico, em seu campo profissional.</p>`,

    dsAMS: `<h2>Desenvolvimento de Sistemas – AMS</h2>
          <p>É o profissional que analisa e projeta sistemas. Constrói, documenta, realiza testes e mantém sistemas de informação. Utiliza ambientes de desenvolvimento e linguagens de programação específica. Modela, implementa e mantém bancos de dados. O candidato que ingressar no curso técnico de Desenvolvimento de Sistemas, na modalidade AMS, poderá prosseguir os estudos em uma Fatec no curso superior de tecnologia em Análise e Desenvolvimento de Sistemas.</p>`,

    logAMS: `<h2>Logística – AMS</h2>
          <p>Logística é o planejamento do caminho feito por um produto ou serviço até chegar ao cliente de forma organizada, rápida e econômica. Para planejar esse caminho, o estudante vai precisar de conhecimentos de matemática, geografia e física. O aluno aprenderá sobre os processos de compra de matérias-primas, incluindo a escolha dos fornecedores, o registro dos pedidos de compra e o recebimento dos materiais adquiridos. O estudante vai aprender também como se deve movimentar as cargas e os produtos dentro de um estoque para decidir se utilizará, por exemplo, um carrinho ou uma empilhadeira, e como se deve armazenar cada tipo de produto e por quanto tempo. Vai estudar ainda sobre a entrega das mercadorias compradas pelos clientes: como organizar a carga para o transporte, qual a embalagem mais adequada (em caixas de papelão ou madeira, em páletes ou contêineres), qual é o tipo de transporte mais adequado para o produto e para o cliente (caminhões, embarcações, trem ou avião), e quais são as principais rotas que podem ser utilizadas. Além disso, o estudante aprenderá sobre os custos envolvidos em cada uma das atividades. O candidato que ingressar no curso técnico de Logística, na modalidade AMS, poderá prosseguir os estudos em uma Fatec no curso superior de tecnologia em Logística.</p>`
  };

  if (confirm("Deseja abrir informações sobre este curso?")) {
    const novaJanela = window.open("", "_blank", "width=700,height=500,scrollbars=yes");
    novaJanela.document.write(`
      <html>
        <head>
          <title>Curso</title>
          <style>
            body { font-family: Arial, sans-serif; padding: 20px; line-height: 1.6; }
            h2 { color: #2c3e50; margin-bottom: 15px; }
            p { text-align: justify; margin-bottom: 10px; }
          </style>
        </head>
        <body>
          ${conteudos[curso] || "<p>Informações não disponíveis.</p>"}
        </body>
      </html>
    `);
  }
}
