function SomaQuadrado() {
    let n1 = Number(document.getElementById('num1').value);
    let n2 = Number(document.getElementById('num2').value);
    let n3 = Number(document.getElementById('num3').value);
   
    let numeros = [n1, n2, n3];
    let soma = 0;
   
    for (let i = 0; i < numeros.length; i++) {
      soma += numeros[i];
    }
   
    let quad1 = numeros[0] * numeros[0];
    let quad2 = numeros[1] * numeros[1];
   
    document.getElementById('resEx1').innerText =
      "A soma dos três números é: " + soma +
      ", o quadrado do primeiro é: " + quad1 +
      " e o quadrado do segundo é: " + quad2;
  }
   
  function CombinacaoLetra() {
    let l1 = document.getElementById('let1').value.toUpperCase();
    let l2 = document.getElementById('let2').value.toUpperCase();
    let l3 = document.getElementById('let3').value.toUpperCase();
    let l4 = document.getElementById('let4').value.toUpperCase();
    let l5 = document.getElementById('let5').value.toUpperCase();
   
    let letras = [l1, l2, l3, l4, l5];
    let palavras = [];
   
    while (palavras.length < 10) {
      let palavra = "";
      for (let i = 0; i < 5; i++) {
        let pos = Math.floor(Math.random() * letras.length);
        palavra += letras[pos];
      }
      if (!palavras.includes(palavra)) {
        palavras.push(palavra);
      }
    }
   
    document.getElementById('resEx2').innerText = "Palavras: " + palavras.join(", ");
  }