//função para imprimir a primeira parte
function Parte1(){
    for(let i = 1; i <= 10; i++){
        console.log("primeira parte:" + i);
    }
}
setTimeout(Parte1, 2000); //para atrasar

const fs = require("fs").promises; //importando a versão do promisse
fs.readFile("file.txt", 'utf8')// o "utf8" evita a necessidade de to.string()
.then(data =>{
    const registros = data.split("/n");
    registros.forEach((registro, index) =>{
        console.log("Segunda Parte: " + registro + index)
});
})
.catch(err=>{
    console.log("Erro ao ler o arquivo.", err);
});
