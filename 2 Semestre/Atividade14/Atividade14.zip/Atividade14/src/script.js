function validar() {
  let form = document.formulario;
  let nome = form.nome.value.trim();
  let email = form.email.value.trim();
  let comentario = form.comentario.value.trim();
  let pesquisa = form.pesquisa.value;

  if (nome.length < 10) {
    alert("O nome deve ter pelo menos 10 caracteres.");
    return false;
  }

  if (!email.includes("@")) {
    alert("Digite um e-mail válido.");
    return false;
  }

  if (comentario.length < 20) {
    alert("O comentário deve ter pelo menos 20 caracteres.");
    return false;
  }

  if (!pesquisa) {
    alert("Selecione uma opção da pesquisa.");
    return false;
  }

  if (pesquisa === "sim") {
    alert("Volte sempre a esta página!");
  } else {
    alert("Que bom que você voltou a visitar esta página!");
  }

  form.reset();
  return false;
}
