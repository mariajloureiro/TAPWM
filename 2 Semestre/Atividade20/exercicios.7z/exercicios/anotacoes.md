C:\Users\Rafaela\Documents\FATEC\Programação WEB e Mobile\pwebnode\exercicios>npm install express --save 

added 70 packages, and audited 71 packages in 3s

14 packages are looking for funding
  run `npm fund` for details

found 0 vulnerabilities

C:\Users\Rafaela\Documents\FATEC\Programação WEB e Mobile\pwebnode\exercicios>npm install ejs --save

added 8 packages, and audited 79 packages in 2s

14 packages are looking for funding
  run `npm fund` for details

found 0 vulnerabilities

C:\Users\Rafaela\Documents\FATEC\Programação WEB e Mobile\pwebnode\exercicios>npm install nodemon --save-dev

added 26 packages, and audited 105 packages in 6s

18 packages are looking for funding
  run `npm fund` for details

found 0 vulnerabilities

C:\Users\Rafaela\Documents\FATEC\Programação WEB e Mobile\pwebnode\exercicios>nodemon exercicio7.js
'nodemon' não é reconhecido como um comando interno
ou externo, um programa operável ou um arquivo em lotes.

C:\Users\Rafaela\Documents\FATEC\Programação WEB e Mobile\pwebnode\exercicios>           

C:\Users\Rafaela\Documents\FATEC\Programação WEB e Mobile\pwebnode\exercicios>

C:\Users\Rafaela\Documents\FATEC\Programação WEB e Mobile\pwebnode\exercicios>npm start 

> site_fatec@1.0.0 start
> npx nodemon app.js

[nodemon] 3.1.10
[nodemon] to restart at any time, enter `rs`
[nodemon] watching path(s): *.*
[nodemon] watching extensions: js,mjs,cjs,json
[nodemon] starting `node app.js`
Servidor com express foi carregado