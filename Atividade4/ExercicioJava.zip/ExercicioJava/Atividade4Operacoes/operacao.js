function fazerOperacoes() {
    let num1 = parseFloat(prompt("Digite o primeiro número:"));
    let num2 = parseFloat(prompt("Digite o segundo número:"));
  
    if (confirm("Deseja ver o resultado das operações?")) {
      let soma = num1 + num2;
      let subtracao = num1 - num2;
      let produto = num1 * num2;
      let divisao = num1 / num2;
      let resto = num1 % num2;
  
      alert("Soma: " + soma +
            "\nSubtração: " + subtracao +
            "\nMultiplicação: " + produto +
            "\nDivisão: " + divisao.toFixed(2) +
            "\nResto da divisão: " + resto);
    } else {
      alert("Operações canceladas.");
    }
  }
  